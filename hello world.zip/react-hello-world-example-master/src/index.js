import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(<h1>Hello React World..!</h1>,
    document.getElementById('app'));