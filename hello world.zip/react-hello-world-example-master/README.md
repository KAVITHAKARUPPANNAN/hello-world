# react-hello-world-example

README

What is this repository for?

  A basic hello world example using reactJS.
    
  Version 1.0
  
  Note: This repository is very basic setup for reactjs project using
  babel, webpack & react. You can use it as a boilerplate for
  your reactJs projects. 
  
How do I get set up?

Setup-

  1. Clone repository on your local machine
  2. npm install
  
To run app-

  1. npm run build (to bundle all your changes)
  2. npm start (to start the server)
  3. goto http://localhost:8080
  
Who do I talk to?

Repo owner or admin

#ReactJS, #WEBPACK, #BABEL, #Javascript
